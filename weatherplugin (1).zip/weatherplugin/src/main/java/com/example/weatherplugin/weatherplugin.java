package com.example.weatherplugin;
import hudson.Launcher;
import hudson.model.AbstractBuild;
import hudson.model.BuildListener;
import hudson.tasks.BuildStepDescriptor;
import hudson.tasks.BuildStepMonitor;
import hudson.tasks.Builder;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class weatherplugin {
    private final String apiKey;   // Your OpenWeatherMap API key
    private final String cityName; // City name for weather information

    // Constructor for initializing plugin configuration
    public weatherplugin(String apiKey, String cityName) {
        this.apiKey = apiKey;
        this.cityName = cityName;
    }

    public String getApiKey() {
        return apiKey;
    }

    public String getCityName() {
        return cityName;
    }

    @Override
    public boolean perform(AbstractBuild<?, ?> build, Launcher launcher, BuildListener listener)
            throws InterruptedException, IOException {

        try {
            
            String apiUrl = String.format("https://api.openweathermap.org/data/2.5/weather?q=%s&appid=%s&units=metric",
                    getCityName(), getApiKey());

            
            URL url = new URL(apiUrl);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("GET");

            
            int responseCode = connection.getResponseCode();
            if (responseCode == HttpURLConnection.HTTP_OK) {
                Scanner scanner = new Scanner(connection.getInputStream());
                StringBuilder response = new StringBuilder();

                while (scanner.hasNextLine()) {
                    response.append(scanner.nextLine());
                }

                
                double temperature = parseTemperatureFromResponse(response.toString());

                // Determine deployment approval based on the temperature
                boolean allowDeployment = temperature > 20;

                // Display a message in the Jenkins job console output
                if (allowDeployment) {
                    listener.getLogger().println("Deployment allowed. Temperature is " + temperature + " degrees Celsius.");
                } else {
                    listener.getLogger().println("Deployment declined. Temperature is " + temperature + " degrees Celsius or less.");
                }

                return allowDeployment;
            } else {
                listener.getLogger().println("Failed to retrieve weather information. HTTP response code: " + responseCode);
            }

        } catch (Exception e) {
            listener.getLogger().println("Error: " + e.getMessage());
        }

        return false;  
    }

    private double parseTemperatureFromResponse(String response) {
        return 0.0;
    }

    @Override
    public BuildStepMonitor getRequiredMonitorService() {
        return BuildStepMonitor.BUILD;
    }
 // Descriptor for the plugin
 @SuppressWarnings("rawtypes")
 public static class DescriptorImpl extends BuildStepDescriptor<Builder> {

     @Override
     public boolean isApplicable(Class clazz) {
         
         return true;
     }
     @Override
     public String getDisplayName() {
         return "Jenkins Plugin";  
     }
 }
}
