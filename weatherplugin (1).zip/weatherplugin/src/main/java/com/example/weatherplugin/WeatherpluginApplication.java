package com.example.weatherplugin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherpluginApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeatherpluginApplication.class, args);
	}

}
