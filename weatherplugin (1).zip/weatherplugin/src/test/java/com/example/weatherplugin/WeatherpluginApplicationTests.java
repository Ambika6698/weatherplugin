package com.example.weatherplugin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherpluginApplicationTests {

	@Test
	void contextLoads() {
	}

}
